
<h1>home</h1>
<a href="/about">About</a>
<a href="/board">게시판</a>
