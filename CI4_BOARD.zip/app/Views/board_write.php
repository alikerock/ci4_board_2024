<h1>게시판 - 글쓰기</h1>

<a href="/">home</a>
<a href="/board">목록</a>
